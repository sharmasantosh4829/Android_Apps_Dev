package com.example.intentpassingexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_next;
        btn_next = findViewById(R.id.btn_next);

        Intent i_next;
        i_next = new Intent(MainActivity.this, SecondActivity.class);
        i_next.putExtra("title", "Home");
        i_next.putExtra("StudentName", "Santosh Sharma");
        i_next.putExtra("Roll No.", 10);

        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(i_next);
            }
        });

    }
}