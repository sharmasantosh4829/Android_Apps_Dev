package com.example.intentpassingexample;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class SecondActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

//        Button btn_previous;
//        btn_previous = findViewById(R.id.btn_previous);

        Intent fetch_from_main_activity = getIntent();
        String title = fetch_from_main_activity.getStringExtra("title");
        String student_name = fetch_from_main_activity.getStringExtra("StudentName");
        int student_roll_no = fetch_from_main_activity.getIntExtra("Roll No.", 0);

        TextView txt_student_info;
        txt_student_info = findViewById(R.id.txt_student_info);
        txt_student_info.setText("Student Name: "+ student_name + "\nRoll no: "+ student_roll_no);
        try {
            getSupportActionBar().setTitle(title);
        }catch (NullPointerException npe){
            Toast.makeText(this, "test", Toast.LENGTH_SHORT).show();
        }

//        btn_previous.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i_previous = new Intent(SecondActivity.this, MainActivity.class);
//                startActivity(i_previous);
//            }
//        });
    }
}