package com.example.tablayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    TabLayout tab;
    ViewPager2 viewPager2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tab = findViewById(R.id.tab);
        viewPager2 = findViewById(R.id.view_pager);

        ViewPagerMessengerAdapter viewPagerMessengerAdapter = new ViewPagerMessengerAdapter(this);
        viewPager2.setAdapter(viewPagerMessengerAdapter);
//        tab.setupWithViewPager(viewPager2, true);
        new TabLayoutMediator(tab, viewPager2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                String tabTitle = "";
                if (position == 0) {
                    tabTitle = "CHATS";
                } else if (position == 1) {
                    tabTitle = "STATUS";
                } else {
                    tabTitle = "CALLS";
                }
                tab.setText(tabTitle);
            }
        }).attach();
    }
}