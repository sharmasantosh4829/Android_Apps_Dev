package com.example.database;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBHelper dbHelper = new DBHelper(this);
//        dbHelper.addContact("Santosh", "0987654321");
//        dbHelper.addContact("Santosh1", "097654321");
//        dbHelper.addContact("Santosh2", "09876321");
//        dbHelper.addContact("Santosh3", "09854321");
//        dbHelper.addContact("Santosh4", "09876541");

        ContactsModel contactsModel = new ContactsModel();
        contactsModel.id = 1;
        contactsModel.phone_no = "1234567890";

//        dbHelper.updateContact(contactsModel);
        dbHelper.deleteContacts(2);
        ArrayList<ContactsModel> arrContacts = dbHelper.getContacts();

        for(int i=0; i<arrContacts.size(); i++){
            Log.d("CONTACT_INFO",
                    "Name: " + arrContacts.get(i).name + ", Phone No: " + arrContacts.get(i).phone_no);
        }
    }
}