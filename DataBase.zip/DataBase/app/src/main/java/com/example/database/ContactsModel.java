package com.example.database;

public class ContactsModel {

    int id;
    String name, phone_no;
}
