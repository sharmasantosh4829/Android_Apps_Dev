package com.example.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ContactsDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_CONTACT = "contacts";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_PHONE_NUMBER = "phone_no";



    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    // CREATE TABLE contacts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone_no TEXT)
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_CONTACT + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_PHONE_NUMBER + " TEXT" + ")");

//        SQLiteDatabase database = this.getWritableDatabase(); //Open db
//
//        database.close(); //close db
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACT);
        onCreate(db);

    }
     //CRUD operations
    //1. Create/Insert in db
    public void addContact(String name, String phone_no){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME, name);
        contentValues.put(KEY_PHONE_NUMBER, phone_no);
        db.insert(TABLE_CONTACT, null, contentValues);

    }

    //2. Read/Fetch from db
    public ArrayList<ContactsModel> getContacts(){
        SQLiteDatabase db = this.getReadableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("Select * from " + TABLE_CONTACT,
                null);

        ArrayList<ContactsModel> arrContacts = new ArrayList<>();
        while (cursor.moveToNext()){
            ContactsModel contactsModel = new ContactsModel();
            contactsModel.id = cursor.getInt(0);
            contactsModel.name = cursor.getString(1);
            contactsModel.phone_no = cursor.getString(2);

            arrContacts.add(contactsModel);
        }
        return arrContacts;
    }

    //3. Update db
    public void updateContact(ContactsModel contactsModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_PHONE_NUMBER, contactsModel.phone_no);
        db.update(TABLE_CONTACT, contentValues, KEY_ID +" = "+contactsModel.id, null);
    }

    //4. Delete from db
    public void deleteContacts(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACT, KEY_ID +" = ? ", new String[]{String.valueOf(id)});
    }
}
