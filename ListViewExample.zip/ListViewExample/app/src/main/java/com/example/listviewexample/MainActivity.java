package com.example.listviewexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list_view;
    Spinner spinner;
    AutoCompleteTextView actxt_view ;
//    int[] arr_no = new int[]{1, 2, 3, 4, 5};
    ArrayList<String> arr_names = new ArrayList<>();
    ArrayList<String> arr_ids = new ArrayList<>();
    ArrayList<String> arr_languages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list_view = findViewById(R.id.list_view);
        spinner = findViewById(R.id.spinner);
        actxt_view = findViewById(R.id.actxt_view);

        arr_names.add("Suman");
        arr_names.add("Santosh");
        arr_names.add("Sushma");
        arr_names.add("Gitali");
        arr_names.add("Vivaan");
        arr_names.add("Suman");
        arr_names.add("Santosh");
        arr_names.add("Sushma");
        arr_names.add("Gitali");
        arr_names.add("Vivaan");
        arr_names.add("Suman");
        arr_names.add("Santosh");
        arr_names.add("Sushma");
        arr_names.add("Gitali");
        arr_names.add("Vivaan");
        arr_names.add("Suman");
        arr_names.add("Santosh");
        arr_names.add("Sushma");
        arr_names.add("Gitali");
        arr_names.add("Vivaan");

        ArrayAdapter<String> arr_adapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_1,
                arr_names);
        list_view.setAdapter(arr_adapter);

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position==0){
                    Toast.makeText(MainActivity.this, "1st item clicked", Toast.LENGTH_SHORT).show();
                }
            }
        });

        arr_ids.add("Adhar Card");
        arr_ids.add("PAN Card");
        arr_ids.add("VoterID Card");
        arr_ids.add("Driving License Card");
        arr_ids.add("Ration Card");
        arr_ids.add("Xth Score Card");
        arr_ids.add("XII Score Card");

        ArrayAdapter<String> spinner_adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                arr_ids);

        spinner.setAdapter(spinner_adapter);

        arr_languages.add("C");
        arr_languages.add("C++");
        arr_languages.add("Java");
        arr_languages.add("Python");
        arr_languages.add("PHP");
        arr_languages.add("C#");
        arr_languages.add("Cscript");

        ArrayAdapter<String> actxt_view_adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1,
                arr_languages);

        actxt_view.setAdapter(actxt_view_adapter);
        actxt_view.setThreshold(1);

    }
}