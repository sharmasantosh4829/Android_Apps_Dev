package com.example.alarmmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final int ALARM_REQ_CODE = 100;

    EditText edt_time;
    Button btn_set_alarm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_time = findViewById(R.id.edt_time);
        btn_set_alarm = findViewById(R.id.btn_set_alarm);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        btn_set_alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int time = Integer.parseInt(edt_time.getText().toString());
                long trigger_time = System.currentTimeMillis()+(time* 1000L);
                Intent i_broadcast = new Intent(MainActivity.this, MyReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        MainActivity.this,
                        ALARM_REQ_CODE,
                        i_broadcast,
                        PendingIntent.FLAG_IMMUTABLE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, trigger_time, pendingIntent);

            }
        });

    }
}