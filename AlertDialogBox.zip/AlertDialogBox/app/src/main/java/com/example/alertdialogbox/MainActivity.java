package com.example.alertdialogbox;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_open_dialog_box;
    Button btn_open_custom_dialog_box;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_open_dialog_box = findViewById(R.id.btn_open_dialog_box);
        btn_open_custom_dialog_box = findViewById(R.id.btn_open_custom_dialog_box);

        btn_open_custom_dialog_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.custom_alert_dialog_box);
                dialog.setCancelable(false);
                Button btn_okay = dialog.findViewById(R.id.btn_okay);
                btn_okay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "Closed", Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });

        btn_open_dialog_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Single btn dialog box
                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();

                alertDialog.setTitle("Terms and Conditions");
                alertDialog.setIcon(R.drawable.baseline_info_24);
                alertDialog.setMessage("Have you read all the Terms and Conditions?");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes, I've read", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "You can proceed now", Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog.show();

                //Double btn dailog box
                AlertDialog.Builder delDialog = new AlertDialog.Builder(MainActivity.this);
                delDialog.setIcon(R.drawable.baseline_delete_24);
                delDialog.setTitle("Delete");
                delDialog.setMessage("Are you sure you want to delete?");
                delDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "Item Deleted", Toast.LENGTH_SHORT).show();
                    }
                });
                delDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "Item Not Deleted", Toast.LENGTH_SHORT).show();
                    }
                });
                delDialog.show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder exitDialog = new AlertDialog.Builder(MainActivity.this);
        exitDialog.setTitle("Exit");
        exitDialog.setIcon(R.drawable.baseline_exit_to_app_24);
        exitDialog.setMessage("Are you sure you want to exit?");
        exitDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.super.onBackPressed();
                Toast.makeText(MainActivity.this, "App exited", Toast.LENGTH_SHORT).show();
            }
        });
        exitDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Welcome Back!", Toast.LENGTH_SHORT).show();
            }
        });
        exitDialog.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Operation Cancelled", Toast.LENGTH_SHORT).show();
            }
        });
        exitDialog.show();

    }
}