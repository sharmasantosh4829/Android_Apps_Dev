package com.example.toast;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_toast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_toast = findViewById(R.id.btn_toast);
        btn_toast.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {

//                Default Toast
//                Toast.makeText(MainActivity.this, "Show Toast", Toast.LENGTH_SHORT).show();
//
//                Custom Toast
                Toast toast = new Toast(MainActivity.this);
                View view = getLayoutInflater().inflate(R.layout.custom_toast_layout,
                        (ViewGroup) findViewById(R.id.ll_view_container));
                toast.setView(view);
                TextView txt_toast_message = view.findViewById(R.id.txt_toast_message);
                txt_toast_message.setText("Message Sent Successfully");
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP|Gravity.END, 0, 0);
                toast.show();
            }
        });
    }
}