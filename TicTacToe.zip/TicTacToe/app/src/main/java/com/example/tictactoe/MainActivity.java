package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9;
    String btn_1_txt, btn_2_txt, btn_3_txt, btn_4_txt, btn_5_txt, btn_6_txt, btn_7_txt, btn_8_txt, btn_9_txt;
    int flag = 0;
    int moves = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

    }

    private void init(){
        btn_1 = findViewById(R.id.btn_1);
        btn_2 = findViewById(R.id.btn_2);
        btn_3 = findViewById(R.id.btn_3);
        btn_4 = findViewById(R.id.btn_4);
        btn_5 = findViewById(R.id.btn_5);
        btn_6 = findViewById(R.id.btn_6);
        btn_7 = findViewById(R.id.btn_7);
        btn_8 = findViewById(R.id.btn_8);
        btn_9 = findViewById(R.id.btn_9);
    }

    public void check(View view) {
        Button btn_current = (Button) view;
        if (btn_current.getText().toString().equals("")) {
            moves++;
            if (flag == 0) {
                btn_current.setText("X");
                flag = 1;
            } else {
                btn_current.setText("O");
                flag = 0;
            }

            if (moves > 4) {
                btn_1_txt = btn_1.getText().toString();
                btn_2_txt = btn_2.getText().toString();
                btn_3_txt = btn_3.getText().toString();
                btn_4_txt = btn_4.getText().toString();
                btn_5_txt = btn_5.getText().toString();
                btn_6_txt = btn_6.getText().toString();
                btn_7_txt = btn_7.getText().toString();
                btn_8_txt = btn_8.getText().toString();
                btn_9_txt = btn_9.getText().toString();

                // Conditions
                if (btn_1_txt.equals(btn_2_txt) && btn_2_txt.equals(btn_3_txt) && !btn_1_txt.equals("")) {
                    //1
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_1_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_4_txt.equals(btn_5_txt) && btn_5_txt.equals(btn_6_txt) && !btn_4_txt.equals("")) {
                    //2
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_4_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_7_txt.equals(btn_8_txt) && btn_8_txt.equals(btn_9_txt) && !btn_7_txt.equals("")) {
                    //3
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_7_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_1_txt.equals(btn_4_txt) && btn_4_txt.equals(btn_7_txt) && !btn_1_txt.equals("")) {
                    //4
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_1_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_2_txt.equals(btn_5_txt) && btn_5_txt.equals(btn_8_txt) && !btn_2_txt.equals("")) {
                    //5
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_2_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_3_txt.equals(btn_6_txt) && btn_6_txt.equals(btn_9_txt) && !btn_3_txt.equals("")) {
                    //6
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_3_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_1_txt.equals(btn_5_txt) && btn_5_txt.equals(btn_9_txt) && !btn_1_txt.equals("")) {
                    //7
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_1_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (btn_3_txt.equals(btn_5_txt) && btn_5_txt.equals(btn_7_txt) && !btn_3_txt.equals("")) {
                    //8
                    Toast.makeText(getApplicationContext(), "Winner is: " + btn_3_txt, Toast.LENGTH_LONG).show();
                    restartGame();
                } else if (moves==9) {
                    //9
                    Toast.makeText(getApplicationContext(), "It's a Tie", Toast.LENGTH_LONG).show();
                    restartGame();
                }
            }
        }

    }
    public void restartGame(){
        btn_1.setText("");
        btn_2.setText("");
        btn_3.setText("");
        btn_4.setText("");
        btn_5.setText("");
        btn_6.setText("");
        btn_7.setText("");
        btn_8.setText("");
        btn_9.setText("");
        moves=0;
        flag=0;
    }

}