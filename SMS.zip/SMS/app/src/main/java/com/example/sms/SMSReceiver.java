package com.example.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;

public class SMSReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle bundle = intent.getExtras(); //Receiving PDUs
        Object[] sms_obj = (Object[]) bundle.get("pdus");

        for(Object obj: sms_obj){
            SmsMessage message = SmsMessage.createFromPdu((byte[])obj);
            String mob_no = message.getDisplayOriginatingAddress();
            String msg = message.getDisplayMessageBody();

            Log.d("MsgDetails", "MobNo: "+ mob_no + ", Msg: " +msg);

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "+91987654321",
                    null,
                    "Hello",
                    null,
                    null);
        }

    }
}
