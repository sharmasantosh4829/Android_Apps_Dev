package com.example.notifications;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private static final String CHANNEL_ID = "Message Channel";

    private static final String CHANNEL_NAME = "Message";
    private static final int NOTIFICATION_ID = 100;

    private static final int REQ_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Drawable drawable = ResourcesCompat.getDrawable(getResources(), R.drawable.icon, null);
        BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
        assert bitmapDrawable != null;
        Bitmap largeIcon = bitmapDrawable.getBitmap();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification builder;
        Intent intent_notify = new Intent(getApplicationContext(), MainActivity.class);
        intent_notify.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this,
                REQ_CODE,
                intent_notify,
                PendingIntent.FLAG_IMMUTABLE);

        //Big Picture Style
        NotificationCompat.BigPictureStyle bigPictureStyle = new NotificationCompat.BigPictureStyle()
                .bigPicture(((BitmapDrawable)(Objects.requireNonNull(ResourcesCompat.getDrawable(getResources(), R.drawable.icon, null)))).getBitmap())
                .bigLargeIcon(largeIcon)
                .setBigContentTitle("Img sent by Santosh")
                .setSummaryText("Img Message");

        //Inbox Style
        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle()
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .setBigContentTitle("Full Message")
                .setSummaryText("Msg Santosh");
        builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setLargeIcon(largeIcon)
                .setSmallIcon(R.drawable.icon)
                .setContentText("New Message")
                .setSubText("From Santosh")
                .setChannelId(CHANNEL_ID)
                .setContentIntent(pendingIntent)
                .setStyle(inboxStyle)
                .setOngoing(true)
                .build();
        notificationManager.createNotificationChannel(new NotificationChannel(CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH));
        notificationManager.notify(NOTIFICATION_ID, builder);
    }
}