package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<ContactModel> arr_contacts = new ArrayList<>();

    RecyclerView recycler_contact;
    RecyclerContactAdapter adapter;
    FloatingActionButton btn_open_dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler_contact = findViewById(R.id.recycler_contact);
        btn_open_dialog = findViewById(R.id.btn_open_dialog);

        btn_open_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.add_update_layout);

                EditText edt_name = dialog.findViewById(R.id.edt_name);
                EditText edt_number = dialog.findViewById(R.id.edt_number);
                Button btn_action = dialog.findViewById(R.id.btn_action);

                btn_action.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = "", number = "";
                        if (!edt_name.getText().toString().equals("")) {
                            name = edt_name.getText().toString();
                        } else {
                            Toast.makeText(MainActivity.this, "Please enter Contact Name", Toast.LENGTH_SHORT).show();
                        }
                        if (!edt_number.getText().toString().equals("")) {
                            number = edt_number.getText().toString();
                        } else {
                            Toast.makeText(MainActivity.this, "Please enter Contact Number", Toast.LENGTH_SHORT).show();
                        }

                        arr_contacts.add(new ContactModel(name, number));
                        adapter.notifyItemInserted(arr_contacts.size()-1);
                        recycler_contact.scrollToPosition(arr_contacts.size()-1);
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        recycler_contact.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        arr_contacts.add(new ContactModel(R.drawable.man, "Man", "9716814829"));
        arr_contacts.add(new ContactModel(R.drawable.chewing_gum, "Man", "9716814129"));
        arr_contacts.add(new ContactModel(R.drawable.gamer, "Man", "9716814239"));
        arr_contacts.add(new ContactModel(R.drawable.girl, "Man", "9716845829"));
        arr_contacts.add(new ContactModel(R.drawable.panda, "Man", "9715614829"));
        arr_contacts.add(new ContactModel(R.drawable.profile, "Man", "9676814829"));
        arr_contacts.add(new ContactModel(R.drawable.user, "Man", "9716784829"));
        arr_contacts.add(new ContactModel(R.drawable.woman, "Man", "9713214829"));
        arr_contacts.add(new ContactModel(R.drawable.woman_1, "Man", "9714514829"));
        arr_contacts.add(new ContactModel(R.drawable.girl, "Man", "9716810929"));
        arr_contacts.add(new ContactModel(R.drawable.man, "Man", "9716810989"));
        arr_contacts.add(new ContactModel(R.drawable.chewing_gum, "Man", "9016814829"));
        arr_contacts.add(new ContactModel(R.drawable.panda, "Man", "9716816529"));
        arr_contacts.add(new ContactModel(R.drawable.user, "Man", "9716814769"));
        arr_contacts.add(new ContactModel(R.drawable.profile, "Man", "9716984829"));
        arr_contacts.add(new ContactModel(R.drawable.gamer, "Man", "9716819829"));

        adapter = new RecyclerContactAdapter(MainActivity.this, arr_contacts);
        recycler_contact.setAdapter(adapter);


    }
}