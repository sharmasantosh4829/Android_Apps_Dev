package com.example.recyclerview;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerContactAdapter extends RecyclerView.Adapter<RecyclerContactAdapter.ViewHolder> {

    Context context;
    ArrayList<ContactModel> arr_contacts;

    private int lastPosition = -1;

    RecyclerContactAdapter(Context context, ArrayList<ContactModel> arr_contacts){
        this.context = context;
        this.arr_contacts = arr_contacts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.contact_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.img_contact.setImageResource(arr_contacts.get(position).img);
        holder.txt_name.setText(arr_contacts.get(position).name);
        holder.txt_number.setText(arr_contacts.get(position).number);
        setAnimation(holder.itemView, position);
        holder.ll_row.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.add_update_layout);

                EditText edt_name = dialog.findViewById(R.id.edt_name);
                EditText edt_number = dialog.findViewById(R.id.edt_number);
                Button btn_action = dialog.findViewById(R.id.btn_action);
                btn_action.setText("Update");
                TextView txt_title = dialog.findViewById(R.id.txt_title);
                txt_title.setText("Update Contact");
                edt_name.setText(arr_contacts.get(position).name);
                edt_number.setText(arr_contacts.get(position).number);

                btn_action.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = "", number = "";
                        if (!edt_name.getText().toString().equals("")) {
                            name = edt_name.getText().toString();
                        } else {
                            Toast.makeText(context, "Please enter Contact Name", Toast.LENGTH_SHORT).show();
                        }
                        if (!edt_number.getText().toString().equals("")) {
                            number = edt_number.getText().toString();
                        } else {
                            Toast.makeText(context, "Please enter Contact Number", Toast.LENGTH_SHORT).show();
                        }

                        arr_contacts.set(position, new ContactModel(name, number));
                        notifyItemChanged(position);
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        holder.ll_row.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                AlertDialog.Builder builder =  new AlertDialog.Builder(context)
                        .setTitle("Delete Contact")
                        .setMessage("Are you sure you want to delete?")
                        .setIcon(R.drawable.ic_launcher_background)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                arr_contacts.remove(position);
                                notifyItemRemoved(position);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });

                builder.show();

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return arr_contacts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txt_name, txt_number;
        ImageView img_contact;
        LinearLayout ll_row;

        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            txt_name = itemView.findViewById(R.id.txt_name);
            txt_number = itemView.findViewById(R.id.txt_number);
            img_contact = itemView.findViewById(R.id.img_contact);
            ll_row = itemView.findViewById(R.id.ll_row);
        }
    }

    private void setAnimation(View viewToAnimate, int position) {
        if (position>lastPosition) {
            Animation slideIn = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left);
            viewToAnimate.startAnimation(slideIn);
            lastPosition = position;
        }
    }
}
