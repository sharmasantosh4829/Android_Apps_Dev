package com.example.firebasesampleapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.res.ResourcesCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Objects;

public class FirebaseMsgService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        super.onMessageReceived(message);

//        if(message.getNotification()!=null){
//            pushNotification(
//                    message.getNotification().getTitle(),
//                    message.getNotification().getBody()
//            );
//        }
        pushNotification(
                Objects.requireNonNull(message.getNotification()).getTitle(),
                message.getNotification().getBody()
        );
    }

    private void pushNotification(String title, String msg) {
        final String CHANNEL_ID = "Push Notification";

        final String CHANNEL_NAME = "Message";
        final int NOTIFICATION_ID = 100;

        final int REQ_CODE = 100;

        Drawable drawable = ResourcesCompat.getDrawable(getResources(), R.drawable.icon, null);
        BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
        assert bitmapDrawable != null;
        Bitmap largeIcon = bitmapDrawable.getBitmap();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification builder;
        Intent intent_notify = new Intent(this, MainActivity.class);
        intent_notify.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                REQ_CODE,
                intent_notify,
                PendingIntent.FLAG_IMMUTABLE);

        //Big Picture Style
        NotificationCompat.BigPictureStyle bigPictureStyle = new NotificationCompat.BigPictureStyle()
                .bigPicture(((BitmapDrawable)(Objects.requireNonNull(ResourcesCompat.getDrawable(getResources(), R.drawable.icon, null)))).getBitmap())
                .bigLargeIcon(largeIcon)
                .setBigContentTitle("Img sent by Santosh")
                .setSummaryText("Img Message");

        //Inbox Style
        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle()
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .addLine("ABC")
                .setBigContentTitle("Full Message")
                .setSummaryText("Msg Santosh");
        builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setLargeIcon(largeIcon)
                .setSmallIcon(R.drawable.icon)
                .setAutoCancel(true)
                .setContentTitle(title)
                .setSubText(msg)
                .setChannelId(CHANNEL_ID)
                .setContentIntent(pendingIntent)
                .setStyle(inboxStyle)
                .setOngoing(true)
                .build();
        notificationManager.createNotificationChannel(new NotificationChannel(CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH));
        notificationManager.notify(NOTIFICATION_ID, builder);
    }

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        Log.d("RefreshedToken", token);
    }
}
