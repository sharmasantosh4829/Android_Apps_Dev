package com.example.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Create an executor that executes tasks in a background thread.
        ScheduledExecutorService backgroundExecutor = Executors.newSingleThreadScheduledExecutor();
//
//        // Execute a task in the background thread.
//        backgroundExecutor.execute(new Runnable() {
//            @Override
//            public void run() {
//                // Your code logic goes here.
//            }
//        });

        // Execute a task in the background thread after 5 seconds.
        backgroundExecutor.schedule(new Runnable() {
            @Override
            public void run() {

                SharedPreferences sharedPreferences = getSharedPreferences("login", MODE_PRIVATE);
                boolean check = sharedPreferences.getBoolean("flag", false);
                Intent i_next = null;
                if(check){ //User is already logged in
                    i_next = new Intent(MainActivity.this, HomeActivity.class);
                }else { //For first time or user has logged out
                    i_next = new Intent(MainActivity.this, LoginActivity.class);
                }
                startActivity(i_next);
                finish();
            }
        }, 4, TimeUnit.SECONDS);
    }
}