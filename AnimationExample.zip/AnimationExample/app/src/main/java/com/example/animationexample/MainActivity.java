package com.example.animationexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

//    TextView txt_anim;
    ImageView img_adb_icon;
    Button btn_translate, btn_alpha, btn_rotate, btn_scale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        txt_anim = findViewById(R.id.txt_anim);
        img_adb_icon = findViewById(R.id.img_adb_icon);
        btn_translate = findViewById(R.id.btn_translate);
        btn_alpha = findViewById(R.id.btn_alpha);
        btn_rotate = findViewById(R.id.btn_rotate);
        btn_scale = findViewById(R.id.btn_scale);


        btn_translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation move_animation = AnimationUtils.loadAnimation(MainActivity.this,
                        R.anim.move_animation);
                img_adb_icon.startAnimation(move_animation);
            }
        });

        btn_alpha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation alpha_animation = AnimationUtils.loadAnimation(MainActivity.this,
                        R.anim.alpha_animation);
                img_adb_icon.startAnimation(alpha_animation);
            }
        });

        btn_rotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation rotate_animation = AnimationUtils.loadAnimation(MainActivity.this,
                        R.anim.rotate_animation);
                img_adb_icon.startAnimation(rotate_animation);
            }
        });

        btn_scale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation scale_animation = AnimationUtils.loadAnimation(MainActivity.this,
                        R.anim.scale_animation);
                img_adb_icon.startAnimation(scale_animation);
            }
        });
    }
}