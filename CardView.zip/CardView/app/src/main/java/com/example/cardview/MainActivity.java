package com.example.cardview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.graphics.Color;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

//    CardView card_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        card_view = findViewById(R.id.card_view);
//        card_view.setMinimumWidth(340);
//        card_view.setMinimumHeight(500);
//        card_view.setCardBackgroundColor(Color.BLUE);
//        card_view.setRadius(5.0f);
//        card_view.setCardElevation(11.0f);
//        card_view.setUseCompatPadding(true);

    }
}