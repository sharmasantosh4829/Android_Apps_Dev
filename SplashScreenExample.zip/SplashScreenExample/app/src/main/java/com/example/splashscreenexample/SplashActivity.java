package com.example.splashscreenexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.airbnb.lottie.LottieAnimationView;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SplashActivity extends AppCompatActivity {

//    LottieAnimationView la_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Create an executor that executes tasks in a background thread.
        ScheduledExecutorService backgroundExecutor = Executors.newSingleThreadScheduledExecutor();
//
//        // Execute a task in the background thread.
//        backgroundExecutor.execute(new Runnable() {
//            @Override
//            public void run() {
//                // Your code logic goes here.
//            }
//        });

        // Execute a task in the background thread after 5 seconds.
        backgroundExecutor.schedule(new Runnable() {
            @Override
            public void run() {
                Intent i_home = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(i_home);
//                la_view = findViewById(R.id.la_view);
//                la_view.setAnimation(R.raw.lottie);
                finish();
            }
        }, 5, TimeUnit.SECONDS);

    }
}