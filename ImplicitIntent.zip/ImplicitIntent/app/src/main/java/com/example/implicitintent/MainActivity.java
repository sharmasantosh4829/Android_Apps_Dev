package com.example.implicitintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn_dial, btn_msg, btn_share, btn_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_dial = findViewById(R.id.btn_dial);
        btn_email = findViewById(R.id.btn_email);
        btn_msg = findViewById(R.id.btn_msg);
        btn_share = findViewById(R.id.btn_share);

        btn_dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_dial = new Intent(Intent.ACTION_DIAL);
//                intent_dial.setAction(Intent.ACTION_DIAL);
                intent_dial.setData(Uri.parse("tel: +919716814829"));
                startActivity(intent_dial);
            }
        });

        btn_msg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_msg = new Intent(Intent.ACTION_SENDTO);
                intent_msg.setData(Uri.parse("smsto:"+Uri.encode("+919716814829")));
                intent_msg.putExtra("sms_body", "Please solve this issue ASAP");
                startActivity(intent_msg);
            }
        });

        btn_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_email  = new Intent(Intent.ACTION_SEND);
                intent_email.setType("message/rfc822"); //required for email type messages
                intent_email.putExtra(Intent.EXTRA_EMAIL, new String[]{"santosh.sharma@ril.com", "ss10011987@gmail.com"});
                intent_email.putExtra(Intent.EXTRA_SUBJECT, "Querries");
                intent_email.putExtra(Intent.EXTRA_TEXT, "This is a test message");
                startActivity(Intent.createChooser(intent_email, "Email via")); // id  more than one email apps
            }
        });

        btn_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_share = new Intent(Intent.ACTION_SEND);
                intent_share.setType("text/plain");
                intent_share.putExtra(Intent.EXTRA_TEXT, "Download this app at:");
                startActivity(Intent.createChooser(intent_share, "Share via"));
            }
        });
    }
}