package com.example.googlemaps;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.googlemaps.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.model.PolygonOptions;

import java.io.IOException;
import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Mathura and move the camera
        LatLng mathura = new LatLng(27.4924, 77.6737);
        mMap.addMarker(new MarkerOptions().position(mathura).title("Marker in Mathura"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(mathura));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mathura, 16f));

        //Add circle overlay
        mMap.addCircle(new CircleOptions()
                .center(mathura)
                .radius(1000)
                .fillColor(Color.GREEN)
                .strokeColor(Color.GRAY));

//        //Add Polygon overlay
//        mMap.addPolygon(new PolygonOptions()
//                .add(new LatLng(27.4924, 77.6737),
//                new LatLng(26.4924, 76.6737),
//                new LatLng(28.4924, 78.6737),
//                new LatLng(29.4924, 79.6737),
//                new LatLng(27.4924, 77.6737))
//                .fillColor(Color.YELLOW)
//                .strokeColor(Color.BLUE));

        //Add Image overlay
        mMap.addGroundOverlay(new GroundOverlayOptions()
                .position(mathura, 1000f, 1000f)
                .image(BitmapDescriptorFactory.fromResource(R.drawable.krishna))
                .clickable(true));

        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                mMap.addMarker(new MarkerOptions().position(latLng).title("Clicked here...  "));

                Geocoder geocoder = new Geocoder(MapsActivity.this);
                try {
                    ArrayList<Address> arr_addr = (ArrayList<Address>) geocoder
                            .getFromLocation(latLng.latitude, latLng.longitude, 1);
                    Log.d("ADDR", String.valueOf(arr_addr.get(0).getAddressLine(0)));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }
}