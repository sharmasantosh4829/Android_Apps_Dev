package com.example.videoplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    VideoView video_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        video_view = findViewById(R.id.video_view);

        String video_path = "android.resource://"+ getPackageName()+"/raw/sample_video";
        Uri video_uri = Uri.parse(video_path);

        String online_video_path = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
        Uri online_video_uri = Uri.parse(online_video_path);

//        video_view.setVideoPath(video_path);
        video_view.setVideoURI(online_video_uri);
        video_view.start();

        MediaController mediaController = new MediaController(this);
        video_view.setMediaController(mediaController);
        mediaController.setAnchorView(video_view);
    }
}